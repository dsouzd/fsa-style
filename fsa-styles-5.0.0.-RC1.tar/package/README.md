# Spartacus FSA Styles

Spartacus FSA Styles is a styling library that provides global styling and theming to the @spartacus/fsa-storefront.

The package should be used together with the Spartacus FSA Storefront to build an eCommerce platform using SAP Commerce exclusively through the Commerce REST API.

For more information, see [Spartacus Documentation](https://github.com/SAP/spartacus-financial-services-accelerator).
